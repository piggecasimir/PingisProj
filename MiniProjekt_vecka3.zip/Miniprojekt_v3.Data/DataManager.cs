﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Miniprojekt_v3.Data
{
    public class DataManager
    {
        SqlConnection conn;

        public DataManager()
        {
            string connString = ConfigurationManager.ConnectionStrings["myCon"].ConnectionString;
            conn = new SqlConnection(connString);
        }


        public List<Candy> GetCandyList()
        {
        List<Candy> ret = new List<Candy>();
            Candy candy = new Candy();
            candy.Id = 1;
            candy.ProductName = "Test Candy";
            candy.Price = 5;
            ret.Add(candy);
            Candy candy2 = new Candy();
            candy2.Id = 1;
            candy2.ProductName = "Test Candy";
            candy2.Price = 5;
            ret.Add(candy2);

            return ret;
        }

    }
}
