﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Miniprojekt_v3.Data
{
    //internal är motsvarigheten av Private på en variabel men anpassad för Klasser, ses då bara i sitt projekt Public öppnar det.
    public class Candy
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }


    }
}
